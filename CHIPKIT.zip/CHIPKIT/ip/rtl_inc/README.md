# RTL Macros

This include file contains a minimal set of macros that are valuable when designing hardware using synthesizable RTL.
See RTL coding guidlines elsewhere in this project for more details and examples.
