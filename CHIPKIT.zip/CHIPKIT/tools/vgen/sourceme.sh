#!/usr/bin/env bash

# To store the path of the executing script's directory in var `__DIR__`:
# __DIR__="$(cd "$(dirname "${0}")"; echo "$(pwd)")"

#export PATH=$PATH:$(pwd)/bin
export PYTHONPATH=$PYTHONPATH:$(pwd)/bin


