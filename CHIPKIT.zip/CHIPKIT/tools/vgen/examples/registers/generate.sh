mkdir -p output
./vgen_regs.py --generate cregs.csv --clock HCLK --reset HRESETn --output output


