./vgen_regs.py --update ../CRG.sv --csv cregs.csv --prefix dc_

