import os
import re
import subprocess

# Testdata folder path
testdata_folder = "./results/coverage.vdb/snps/coverage/db/testdata"

# Folders in testdata are named with tests' name
tests_folder = os.listdir(testdata_folder)

# Execute cm_post command to set test_status for each tests
for folder in tests_folder:
	test_status = "unknown"
	log_file_found = False
	for filename in os.listdir("./results"):
		if filename.startswith(folder) and filename.endswith(".log"):
			log_file_found = True
			# Check for UVM_ERROR
			uvm_error_found = False
			with open("./results/"+filename, "r") as f:
				for line in f:
					# Regex pattern
					uvm_error_regex = r"UVM_ERROR (?:\s+)?([^\s]+\.[^\s]+)\((\d+)\) @ (\d+): .*"

					# Search the line using regex
					match = re.search(uvm_error_regex, line)

					# If UVM_ERROR is found
					if match:
						uvm_error_found = True
						break
	if log_file_found == False:
		print("log file not exists: " + folder)
	else:
		# Set test status
		test_status = "fail" if uvm_error_found else "pass"
		print(filename + " " + test_status)

	cmd = ["cm_post", "-dir", "results/coverage.vdb", "-test_status", test_status, "-test_name", "results/coverage/" + folder]
	subprocess.run(cmd)

