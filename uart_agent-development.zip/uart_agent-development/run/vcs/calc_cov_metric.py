import re

def read_text_from_file(filename):
    with open(filename, 'r') as file:
        text = file.read()
    return text

def calculate_coverage_percentage(text):
    # Extract the numerator and denominator
    metric_line = re.search(r'<metric name="Line" value="([^"]+)"', text).group(1)
    numerator, denominator = metric_line.split("/")

    # Convert the numerator and denominator to integers
    numerator = int(numerator)
    denominator = int(denominator)

    # Calculate the percentage and format it with a percent sign
    percentage = (numerator / denominator) * 100
    formatted_percentage = f"{percentage:.2f}"

    # Print the result
    print(formatted_percentage)

if __name__ == "__main__":
    filename = "./results/coverage_html/session.xml"  # Replace with the actual filename
    text = read_text_from_file(filename)
    calculate_coverage_percentage(text)
