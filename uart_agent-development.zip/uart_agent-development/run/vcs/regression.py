import subprocess, sys, getopt
from threading import Thread
from datetime import datetime

## constant definitions ##
TEST_LIST_PATH = "./test_list"

## variables ##
lic_number = 1




## functions ##

# Get -l argument to get the number of license of VCS
def get_args():
    argv = sys.argv[1:]
    try:
        opts, args = getopt.getopt(argv, "l:")
        for opt, arg in opts:
            if opt in ['-l']:
                if arg.isnumeric() and int(arg) > 0:
                    lic_number = arg
                else:
                    print("-l argument should be numeric")
                    exit()
        print("License number:" + lic_number)            
    except:
        print("Cannot get -l argument")
        exit()

# Reading test_file and extracting test names with seed values
def extract_test_list():
    test_list_with_seed = []
    test_list = open(TEST_LIST_PATH,"r")
    for line in test_list:
        # ignore commented lines
        if line.startswith("#"):
            continue
        # remove \n characters
        clean_text = line.strip()
        # split by space character to extract testname and seeds
        splitted_line = clean_text.split(" ")
        test_list_with_seed.append(splitted_line)
    return test_list_with_seed

# Execute make rules to setup and compile before running simulation        
def init_make():
    make_clean = subprocess.run(["make","clean"])
    if make_clean.returncode != 0:
        exit(1)   
    make_setup = subprocess.run(["make","setup"])
    if make_setup.returncode != 0:
        exit(1)    
    make_rtl = subprocess.run(["make","rtl"])
    if make_rtl.returncode != 0:
        exit(1)      
    make_uvm = subprocess.run(["make","uvm"])
    if make_uvm.returncode != 0:
        exit(1)      
    make_elab = subprocess.run(["make","elab", "cov=true"])
    if make_elab.returncode != 0:
        exit(1)    

# Execute make run command with testname and seed value
def run_test(testname_val, seed_val=''):
    testname_arg = "testname={testname}".format(testname=testname_val)
    cmds = ["make", "run", testname_arg, "cov=true"]
    if seed_val != '':
        seed_arg = "seed={seed}".format(seed=seed_val)
        cmds.append(seed_arg)
    print(cmds)
    make_run = subprocess.run(cmds)

# Run all test from test list
def run_test_all(test_list):
    threads = []
    # Max concurrent threads should be equal to license number
    max_threads = lic_number
    for i, row in enumerate(test_list):
        if len(row) == 1:
            print("...Running Testname: " + row[0])
            curr_dt = datetime.now()
            timestamp = int(round(curr_dt.timestamp()))  
            # timestamp used as seed value for randomization
            thread = Thread(target=run_test, args=(row[0], timestamp))
            threads.append(thread)
            continue
        else:           
            for j, item in enumerate(row):
                if j == 0:
                    continue
                print("...Running Testname: " + test_list[i][0] + " Seed: " + test_list[i][j])
                thread = Thread(target=run_test, args=(test_list[i][0], test_list[i][j]))
                threads.append(thread)           
    for i in range(0, len(threads), max_threads):
        batch = threads[i:i + max_threads]
        for thread in batch:
            thread.start()
        for thread in batch:
            thread.join()

get_args()
init_make()
test_list = extract_test_list()
run_test_all(test_list)

