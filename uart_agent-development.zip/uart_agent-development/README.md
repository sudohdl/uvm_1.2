![coverage](http://gitlab.stgm.local/lad/pld/verif/uart_agent/badges/development/coverage.svg)
# STG UART UVC

This is a UVM compatible agent/UVC for driving and monitoring UART bus.

**Note:** [+The files associated with the UVC UART are located in the agents folder. The other folder/files are created to provide a verification environment to test the functionality of the UVC.+]

### :zap: Key Features
- Configurable Reset Polarity
- Configurable Parity settings
- Configurable Stop bit settings
- Error Injection -> Parity
- Error Injection -> Stop Bit
- Parity error detection while monitoring
- Stop bit error detection while monitoring
- Pre-built sequence library
- Packetizer
- Slave sequence (Sending sequence when DUT requested)
- Built-in Assertions
- Baudrate Measurement with Tolerance value

![Architecture of agent](docs/uart_agent_arch.png "Top-Level Architecture of the UVC")

## How to Integrate the UVC
Please follow the steps below to integrate the agent into your test environment:

- Include interface and package files on your top-level testbench module:
```verilog
`include "uart_pkg.svh"
`include "uart_if.svh"
...
module tb_top
...
```
- Import agent package before including your environment files:
```verilog
import uart_pkg::*;
```
- Instantiate the interface on your top-level testbench module, drive the reset and clock signals (Reset polarity can be set on the agent configurations):
```verilog
   uart_if uart_tx_if_inst(
      .reset(reset),
      .clk(clk_uart)
   );
```

- Connect interface to DUT properly :

**Code example for Adaptation Layer:**
```verilog
...

   // DUT Instantiation
   uart_top #(
   ...
   ) uart_rx_inst(
      .clk_i(uart_bus.clk)      ,
      .rst_i (uart_bus.reset)      ,
      ...
      .rx_serial_i   (uart_bus.uart_tx) ,
      ...
   );
...
```
- Set the interface as virtual interface on uvm_config_db. :

```verilog
   initial
   begin
      // Setting interfaces to uvm_config_db
      uvm_config_db #(virtual uart_if)::set(null,"*","uart_vif",uart_if_inst);

      // Execute UVM test class
      run_test("example_test");
   end
```
- Handle the agent configuration class in your environment or environment config class:
```verilog
uart_config h_uart_config;
```
- Handle the agent on your environment class then construct it in build_phase:
```verilog
uart_agent h_uart_agent;
...
h_uart_agent = uart_agent::type_id::create("h_uart_agent",this);
```
- Get the virtual interface from uvm_config_db and assign to the vif in the agent config class
```verilog
   if(!uvm_config_db #(virtual uart_if)::get(this,"", $sformatf("uart_driver_vif"),h_env_cfg.h_uart_config.vif)) begin
      VIF_FATAL: `uvm_fatal("VIF CONFIG","cannot get uart_vif from uvm_config_db. Have you set() it?")
   end

```
- Configure your agent (Config fields to be described later):
```verilog
   h_env_cfg.h_uart_config.is_active = UVM_ACTIVE;
   h_env_cfg.h_uart_config.baud_rate = 9_600;
   h_env_cfg.h_uart_config.num_data_bits = EIGHT_WIDTH;
   h_env_cfg.h_uart_config.reset_polarity = ACTIVE_HIGH;
   h_env_cfg.h_uart_config.parity_type = PARITY_EVEN;
   h_env_cfg.h_uart_config.mon_enable = 1;
   h_env_cfg.h_uart_config.ral_enable = 1;
   h_env_cfg.h_uart_config.pktizer_enable = 1;
```
- Set the config object on uvm_config_db:

**[-Please note that 2nd argument should be same with the instance name of your agent in the UVM factory, and 3rd argument should be "uart_config"-]**
```verilog
   uvm_config_db #(uart_config)::set(this,"h_uart_agent", "uart_config", h_env_cfg.h_uart_config);
```
- There, ready to use! :star:

## Configuration Field of the UVC

| Name       | Description | Default value |
| ---        | ---         | ---           |
| mon_enable | Set 1 to enable monitoring         | 0 |
| pktizer_enable | Set 1 to enable Packetizer         | 0 |
| ral_enable | Set 1 to enable RAL operation in the Packetizer         | 0 |
| reset_polarity | Reset polarity of agent| ACTIVE_LOW |
| baud_rate  | UART Baudrate value | 9600 |
| baud_rate_tolerance | UART Baudrate Tolerance | 0.03 |
| num_data_bits  | UART data width | EIGHT_WIDTH=8 |
| num_stop_bits | UART stop bit config | STOP_BIT_ONEBIT |
| parity_type | UART parity config | PARITY_NONE |
| is_active | Set 1 to create driver and sequencer in the agent | UVM_PASSIVE |

## How to Use UVC as only UART transmitter
- Instantiate only one interface and connect transmitter_port modport to the DUT
- Set the interface driver_vif on config class of the agent by getting uvm_config_db
- Set `mon_enable` to 0
- Set `is_active` to UVM_ACTIVE
- and set the other config fields properly.

## How to Use UVC as only UART receiver
- Instantiate only one interface and connect receiver_port modport to the DUT
- Set the interface mon_vif on config class of the agent by getting uvm_config_db
- Set `mon_enable` to 1
- Set `is_active` to UVM_PASSIVE
- and set the other config fields properly.

## How to Use Packetizer
The Packetizer is implemeted to wrap the received sequence items as uart_packet_seqit in the format described below:
- Header (2 byte)
- Op Code (1 byte)
- Package Length (1 byte)
- Payload (N byte)
- CRC (2 byte)

The packetizer stores the concatenated header and opcode bytes in `defined_headers` array. Those bytes are used to sync the parsing process (generally defined in ICD documents). That array should be filled like below before monitoring the bus:

```verilog
function void test_top::start_of_simulation_phase(uvm_phase phase);
   h_env.h_uart_agent.h_packetizer.defined_headers.push_back({8'hA5, 8'h96, 8'h5A});
   h_env.h_uart_agent.h_packetizer.defined_headers.push_back({8'hA7, 8'h96, 8'h7A});
endfunction:start_of_simulation_phase
```

The packetizer has an analysis port which is named `out_port_ap` to send out the packets which is created with received sequence item. Thus, the packets can be sent out the scoreboard or RAL adapter classes.
### RAL Map in Packetizer
The Packetizer is able to write the registers which are defined on `map`. The type of `map` variable in the packetizer is `uvm_reg_map` and it can be set with a register map of a register model in connect_phase of your environment class like below:

```verilog
function void env_top::connect_phase (uvm_phase phase);
...
   h_uart_agent.h_packetizer.map = blu_regmodel.default_map;
...
endfunction:connect_phase
```

The packetizer uses the concatenated header and opcode information as register address. For example, a UART message is defined on the table below and its header bytes are 0xA596 and its opcode is 0x5A. So, by this message, the registers, which start address is `0xA5965A`, can be set with the payload starting on offset 4. In fact, you can think that EN_STATUS register is located on 0xA5965A address, MODE register on 0xA5965A+1, RESERVED registers 0xA5965A+2, etc. Thus, once this UART message is detected the packetizer, EN_STATUS register is set with Payload data (byte offset 4), MODE regsiter is set with Payload data (byte offset 5) and reserved registers are set with payload (byte offset 6-9)

| Field Name      | Byte Offset | Byte Length | Value or Desc
| ---             | ---         | ---         | ---
| Header          | 0           | 2           | 0xA596
| Op Code         | 2           | 1           | 0x5A
| Package Length  | 3           | 1           | 0x06
| Payload         | 4           | 1           | EN_STATUS register
| Payload         | 5           | 1           | MODE register
| Payload         | 6           | 4           | RESERVED
| CRC             | 10          | 2           | CRC
          
If you want to use this RAL feature, you need to set `ral_enable` configuration field to 1 like below:

```verilog
   h_env_cfg.h_uart_config.ral_enable = 1;
```

## How to Implement a Sequence and Error Injection
You can create your own sequence classes by extending a class from the uvm_sequence parent class like below:

```verilog
class uart_sequence_parity_err extends uart_sequence_base;
   ...
   function new(string name = "uart_sequence_parity_err");
      super.new(name);
      ...
   endfunction:new

   virtual task body();
      $display("uart_sequence_parity_err");
      start_item(req);
      req.data_arr = new[7];
      req.data_arr[0] = 8'hA5;
      req.data_arr[1] = 8'h96;
      req.data_arr[2] = 8'h5C;
      req.data_arr[3] = 8'h01;
      req.data_arr[4] = 8'h09;
      req.data_arr[5] = 8'hAA;
      req.data_arr[6] = 8'hBB;
      req.err_injection = ERROR_PARITY;
      finish_item(req);

   endtask
endclass:uart_sequence_parity_err
```
For instance, you can inject parity or stop bit error by setting err_injection field. The fields to be used while creating a sequence, are provided on the table below:

| Field Name            | Type     | Description 
| ---                   | ---      | ---  
| data_arr              | bit[]    | It should be filled with data at body() task in your sequence
| inter_cycle_delay     | int      | To set delay time between the UART frames    
| start_time            | realtime | It is set by monitor to represent start time of the frame    
| end_time              | realtime | It is set by monitor to represent end time of the frame    
| has_parity_err        | bit      | TODO: unused    
| has_stop_bit_err      | bit      | TODO: unused    
| has_start_bit_glitch  | bit      | If set to 1, the driver creates glitches on start bit    
| has_data_bit_glitch   | bit      | If set to 1, the driver creates glitches on data bits randomly    
| has_parity_bit_glitch | bit      | If set to 1, the driver creates glitches on parity bit
| has_stop_bit_glitch   | bit      | If set to 1, the driver creates glitches on stop bit

## Enabling glitched on the Driver
To enable producing glitches on the bus, you need to set has_*_bit_glitch fields to 1 in your sequences. The glitch starts within random time which is between 0 and bit_time / 2 and remains stable for the duration of a baud tick as seen on the below:

![Producing Glitches](docs/glitch.png "Start time and stable time of the glitch")
    

## How to Implement Slave Sequence
This agent can be used as a Reactive Slave which is meaning that the agent can be trigerred to drive the bus with a request from DUT. The requests are being monitored with the packetizer. Hence, you need to set `pktizer_enable` to 1 before implementing a slave sequence.

Unlike a traditional agent, a reactive slave agent architecture has an additional TLM port between monitor and sequencer, and a TLM FIFO in the sequencer. Thus, we can decode the request from DUT in a sequence class by using p_sequencer.

As seen on below, the sequencer has an uvm_analysis_imp port called `request_export`. This collects sequence items which type are uart_packet_seqit from the packetizer and the opcodes are extracted from the sequence items and sent out the `request_fifo`. There is a uvm_analysis_port needed to write `request_fifo` as uvm_tlm_analysis_fifo cannot be accessed directly. So, `to_fifo` is created and connected to `request_fifo.analysis_export`.

```verilog
class uart_sequencer extends uvm_sequencer #(uart_seqit);
   ...
   // Collect request from packetizer
   uvm_analysis_imp #(uart_packet_seqit, uart_sequencer) request_export;
   uvm_tlm_analysis_fifo #(uart_seqit) request_fifo;
   uvm_analysis_port #(uart_seqit) to_fifo;
   ...
   
   function void connect_phase(uvm_phase phase);
      ...
      to_fifo.connect(request_fifo.analysis_export);
      ...
   endfunction: connect_phase

   // Capture seqits coming from request_export
   // Write only opcode to request_fifo
   function void write(uart_packet_seqit tr);
      ...
      // to_fifo is connected to request_fifo, once written a data, it is sent to request_fifo
      to_fifo.write(tr_);
   endfunction: write

```
## Built-in Assertions
The assertions which are checking serial bus, are defined in `uart_if.svh` interface. Those assertions check the reset response and idle state of the serial bus according to reset_polarity of the UVC.

There is a variable called `err_cnt` in interface and it counts the error number. If this variable reaches `MAX_ERR_CNT_ASSERTION` define, the assertions are disabled. The default value of MAX_ERR_CNT_ASSERTION is 3. But it can be overriden by +define+ argument on simulation commands in Makefile.

The assertions list:
- ap_idle_bus_high - Check the idle state of the bus in case of reset polarity is ACTIVE_HIGH
- ap_idle_bus_low - Check the idle state of the bus in case of reset polarity is ACTIVE_LOW
- ap_reset_response_high - Check the reset response of the bus in case of reset polarity is ACTIVE_HIGH
- ap_reset_response_low - Check the reset response of the bus in case of reset polarity is ACTIVE_LOW

## Baudrate Measurement
The UVC has a built-in function measuring baudrate value and checking that its value within the toleranced range.
Note: To be able to measure baudrate, there are two consecutive UART transfers without any gap.
[+to be continued+]

