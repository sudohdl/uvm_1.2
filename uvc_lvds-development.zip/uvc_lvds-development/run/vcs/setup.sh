# Revision/Date     : 30.10.2023    Furkan Yigit Akyildiz
# ddr_lib added
#
# Revision/Date     : 25.08.2023    Furkan Yigit Akyildiz
# [-reset_run] -- Deletes simulator setup files
# [-create_lib_mappings] -- creates lib mappings
#
usage()
{
  msg="Usage: setup.sh [-help]\n\
Usage: setup.sh [-reset_run]\n\n\
\
[-help] -- Print help\n\n\
[-reset_run] -- Deletes simulator setup files.\n
[-create_lib_mappings] -- Creates simulator setup files(design libraries, simulation libraries, and synopsys_sim.setup file)."
  echo -e $msg
  #exit 0
}

# Create design library directory paths and define design library mappings
create_lib_mappings()
{
    rtl_design_libs=(
                    uart_pkg 
                    )


rtl_sim_libs=(uart_sim_lib uart_lib \
                  lad_top_sim \
                  common_sim_lib \
                  blu_sim_lib)

  file="synopsys_sim.setup"
  dir="vcs_lib"
  result_dir="results"

  if [[ -e $file ]]; then
    rm -f $file
  fi
  if [[ -e $dir ]]; then
    rm -rf $dir
  fi
  if [[ ! -e $result_dir ]]; then
    mkdir -p $result_dir
  fi
  touch $file
  lib_map_path="/prj/stg_common/vcs_xilinx"
  incl_ref="OTHERS=$lib_map_path/synopsys_sim.setup"
  # Design library files mapping
  echo -e "\n-- RTL Design Library Mapping\n" >> $file
  for (( i=0; i<${#rtl_design_libs[*]}; i++ )); do
    lib="${rtl_design_libs[i]}"
    lib_dir="$dir/$lib"
    if [[ ! -e $lib_dir ]]; then
      mkdir -p $lib_dir
      mapping="$lib : $dir/$lib"
      echo $mapping >> $file
    fi
  done
  # Simulation library files mapping
  echo -e "\n-- RTL Simulation Library Mapping\n" >> $file
  for (( i=0; i<${#rtl_design_libs[*]}; i++ )); do
    lib="${rtl_sim_libs[i]}"
    lib_dir="$dir/$lib"
    if [[ ! -e $lib_dir ]]; then
      mkdir -p $lib_dir
      mapping="$lib : $dir/$lib"
      echo $mapping >> $file
    fi
  done
  # Adding compiled library location
  echo -e "\n-- Already Compiled Files\n" >> $file
  echo $incl_ref >> $file

  # Simulator variable settings
  echo -e "\n-- Simulator variable settings" >> $file
  echo -e "\n TIMEBASE = NS\n TIME_RESOLUTION = 1 PS" >> $file
}

# Delete generated files
reset_run()
{
  files_to_remove_current_dir=(hdl.var \
                  64 \
                  ucli.key \
                  AN.DB \
                  csrc \
                  top_tb_\
                  simv \
                  simv.daidir \
                  inter.vpd \
                  vlogan.log \
                  vhdlan.log \
                  compile.log \
                  elaborate.log \
                  simulate.log \
                  .vlogansetup.env \
                  .vlogansetup.args \
                  .vcs_lib_lock \
                  scirocco_command.log \
                  vlogan_vcs.log \
                  DVEfiles \
                  verdiLog \
                  vdCovLog \
                  novas_dump.log \
                  novas.rc \
                  novas.conf \
                  inter.fsdb \
                  )
  for (( j=0; j<${#files_to_remove_current_dir[*]}; j++ )); do
    file_current_dir="${files_to_remove_current_dir[j]}"
    if [[ -e $file_current_dir ]]; then
      rm -rf $file_current_dir
    fi
  done

  files_to_remove=(rtl_lib 
                  )

  for (( i=0; i<${#files_to_remove[*]}; i++ )); do
    file="vcs_lib/${files_to_remove[i]}"
    generated64File="vcs_lib/$file/64"
    generatedANDBFile="vcs_lib/$file/AN.DB"
    if [[ -e $file  ]]; then
      rm -rf $file
    fi
    # if [[ -e $generated64File  ]]; then
    #   rm -rf $generated64File
    # fi
    # if [[ -e $generatedANDBFile  ]]; then
    #   rm -rf $generatedANDBFile
    # fi
  done
}

setup()
{
  case $1 in
    "-reset_run" )
      reset_run
      echo -e "INFO: Simulation run files deleted.\n"
      exit 0
    ;;
    * )
    ;;
  esac

  create_lib_mappings
  echo -e "INFO: Simulation setup files and library mappings created.\n"
  # Add any setup/initialization commands here:-
  # <user specific commands>
}

# Script info
echo -e "setup.sh - Script is generated and launched\n"

# Check command line args
if [[ $# > 1 ]]; then
  echo -e "ERROR: invalid number of arguments specified\n"
  usage
fi

if [[ ($# == 1 ) && ($1 != "-reset_run" && $1 != "-help" && $1 != "-h") ]]; then
  echo -e "ERROR: unknown option specified '$1' (type "setup.sh -help" for for more info)"
  exit 1
fi

if [[ ($1 == "-help" || $1 == "-h") ]]; then
  usage
fi

# Launch script
setup $1
