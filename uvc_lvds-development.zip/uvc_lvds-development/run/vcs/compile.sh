#current directory
origin_dir="../.."

#installation path
bin_path="/home/synopsys/vcs/S-2021.09/bin"

###############################################################################
# COMPILE RTL DESIGN MODULES.
###############################################################################
# set vhdlan command line args
vhdlan_opts="-kdb -full64 -xlrm"
# vhdlan_opts="-kdb"
# set vlogan command line args
#vlogan_opts="-full64 -xlrm"
vlogan_opts="-kdb -v2005"

# compile design source files
$bin_path/vhdlan $vhdlan_opts -work uart_pkg  \
"$origin_dir/rtl/uart_pkg.vhd" \
"$origin_dir/rtl/baud_gen.vhd" \
"$origin_dir/rtl/uart_rx.vhd" \
"$origin_dir/rtl/uart_top.vhd" \
"$origin_dir/rtl/uart_tx.vhd" \

2>&1 | tee -a vhdlan.log

