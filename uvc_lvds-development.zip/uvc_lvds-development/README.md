# UVC_LVDS

This is a UVM compatible UVC for driving and monitoring LVDS bus.

### :zap: Key Notes
- Comply with rising edge of of the clock. It has to be falling edge according to the [datasheet](./docs/20x8_LTPS_AMLCD_tentative_spec_user_manual_ver0.0.pdf).
- This repo wont simulate the results since there is no design files for product phase yet. It will be updated once design is ready to use.
- Comprasion and results can be analyzed in [gitlab](http://gitlab.stgm.local/lad/pld/dev_proj/touch_test/-/tree/7f4b3eb372edb78595663c1af69150dc5b85c0c2).
- Timing checks are done in SVA, and located in interface.
- Synopsys criteria has been considered to develop UVM environment.

## Key Features
- Comply with Power-on Power-off sequences
- Comply with timing configurations (TVS, TVB, TVA, TVF, THB, THF, THS, THA, THF, TCOP)
- Scoreboard compares RGB data with [expected RGB](./docs/RGB.png).
- Panel is driven accordingly L1, L2, R1, R2

![Architecture of agent](docs/uvc_lvds.png "Top-Level Architecture of the UVC")

## How to Integrate the UVC
Please follow the steps below to integrate the agent into your test environment:

- Include interface and package files on your top-level testbench module:
```verilog
`include "lvds_pkg.svh"
`include "lvds_if.svh"
...
module tb_top
...
```
- Import agent package before including your environment files:
```verilog
import lvds_pkg::*;
```
- Instantiate the interface on your top-level testbench module, drive the reset and clock signals (Reset polarity can be set on the agent configurations):
```verilog
lvds_if rctv_slv_if(clk,rst);
```

- Connect interface to DUT via an Adaptation Layer to use modports properly on VHDL designs:
```verilog
   lvds_al lvds_al_inst(rctv_slv_if, rctv_slv_if);
```
**Code example for Adaptation Layer:**
```verilog
module lvds_al (
   // Interface declarations
   lvds_if.lvds_top lvds_top_inst,
   lvds_if.lvds_bottom lvds_bottom_inst
);

```
- Set the interface as virtual interface on uvm_config_db. If you are using driver and monitor, you should set both:

```verilog
   initial
   begin
      // Setting interfaces to uvm_config_db
      uvm_config_db #(virtual lvds_if)::set(null,"*","rctv_slv_if",rctv_slv_if);

      // Execute UVM test class
      run_test();
   end
```
- Handle the agent, coverage and scoreboard class instantiations in the environment class in build phase:
```verilog
   // Decleartions are right after env class
   lvds_scoreboard sb;
   lvds_agent master_agent;
   lvds_cov cov;
   lvds_monitor_2cov_connect mon2cov;
...
   // Below is located in build phase
   master_agent = lvds_agent::type_id::create("master_agent",this); 
   cov = lvds_cov::type_id::create("cov",this); //Instantiating the coverage class
   mon2cov  = lvds_monitor_2cov_connect::type_id::create("mon2cov", this);
   mon2cov.cov = cov;
   sb = lvds_scoreboard::type_id::create("sb",this);

```
- We are still in environment class. Connect phase is for connection between monitor-scoreboard and monitor-coverage
```verilog 
   //Connecting the monitor's analysis ports with lvds_scoreboard's expected analysis exports.
   master_agent.mast_mon.mon_analysis_port.connect(sb.observed);
   //Other monitor element will be connected to the after export of the scoreboard
   master_agent.mast_mon.mon_analysis_port.connect(cov.cov_export);
```
## Work to Do
- Writing 818 data into diffrent bank address for DDR, and compare it with expected data
- Import UART agent
- Generating robustness testcases.

