# STG Notes
This repo cloned from https://github.com/josdejong/jsoneditor/tree/v10.0.3

Latest changes should be tracked on the public repo.

This JSON Editor is customised to add register and block templates. And It also has scheme validation feature according to the scheme which is defined by RegVue

# Usage

Open index.html with a Browser. Then Load a JSON file to edit.

# JSON Editor

JSON Editor is a web-based tool to view, edit, format, and validate JSON. It has various modes such as a tree editor, a code editor, and a plain text editor. The editor can be used as a component in your own web application. It can be loaded as CommonJS module, AMD module, or as a regular javascript file.

The library was originally developed as core component of the popular web application https://jsoneditoronline.org and has been open sourced since then.

Supported browsers: Chrome, Firefox, Safari, Edge.

## License

`jsoneditor` is released as open source under the permissive the [Apache 2.0 license](LICENSE.md).

**If you are using jsoneditor commercially, there is a _social_ (but no legal) expectation that you help fund its maintenance. [Start here](https://github.com/sponsors/josdejong).**
