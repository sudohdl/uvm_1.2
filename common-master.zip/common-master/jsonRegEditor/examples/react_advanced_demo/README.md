# JSONEditor React advanced demo

This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

## Install

Install dependencies once:

```
npm install
```

## Run

To run the demo:

```
npm start
```

This will open a development server at http://localhost:3000
