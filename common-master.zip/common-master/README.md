# common

This repo contains utility classes and functions/tasks (e.g scoreboard, CRC calculation)

This can be added into your repo as submodule
