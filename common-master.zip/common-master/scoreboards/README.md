# stg_scoreboard

stg_scoreboard is a parameterized class which can be set the sequence item type.
It has two TLM ports which are named observed and expected. Once a sequence item is written to observed port,
`write_observed` function is triggered and capturing the sequence item. Then,
the captured sequence item is compared with the item in expected_data queue respectively. To fill expected_data queue, just write `expected` TLM port. 

![Class Diagram](docs/stg_scoreboard.drawio.png "Class Diagram")

## How to Integrate the Scoreboard into Environment
- Include the file in your package:
```verilog
    `include "stg_scoreboard.svh"
```
- Handle the scoreboard class with a sequence item parameter:
```verilog
    stg_scoreboard#(uart_seqit) scb;
```
- Don't forget to construct the class on UVM factory:
```verilog
    scb = stg_scoreboard #(uart_seqit)::type_id::create("scb", this);
```
- In the connect phase, connect the "observed" port with a monitor port 
to be able to capture monitored data:
```verilog
    if (h_uart_agent != null && scb != null) begin
        h_uart_agent.h_monitor.monitor_port_ap.connect(scb.observed);
    end
```
- Fill the expected data of scoreboard in your test class or write data to `expected` TLM port:
```verilog
    bit [7:0] exp_data[3] = {8'hab, 8'hab, 8'hac};
    ...
    foreach (exp_data[i]) begin
        uart_seqit exp_data_;
        exp_data_ = uart_seqit::type_id::create("exp_data_");
        exp_data_.mon_data = exp_data[i];
        h_env.scb.expected_data.push_back(exp_data_);
    end

    ...
    // or write TLM port to fill expected queue by connecting ports
    h_native_fifo_agent.h_monitor.mon_wr_data_ap.connect(scb.expected);

```

## Flush Scoreboard
In some cases, e.g reset state, you might need to clear the content of expected_data array. Then, you can just call the `flush` function
