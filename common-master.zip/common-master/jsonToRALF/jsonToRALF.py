import json, re
from jinja2 import Environment
from jinja2. loaders import FileSystemLoader

templateLoader = FileSystemLoader(searchpath="./")
templateEnv = Environment(loader=templateLoader)
TEMPLATE_FILE = "reg.ralf.j2"
template = templateEnv.get_template(TEMPLATE_FILE)

        

# Load JSON data from file
with open('reg.json') as json_file:
    data = json.load(json_file)

# Accessing elements
elements = data["elements"]
reg_list = {}
total_bits = 0

# Iterate for calculation of total bits of reg fields
for key, value in elements.items():
    if value["type"] == "reg":
        for v in value["fields"]:
            total_bits += v["nbits"]
        value["bytes"] = int(total_bits / 8)
        total_bits = 0

# Find blk and calculate total bytes
for key, value in elements.items():
    if value["type"] == "blk":
        children_list = value["children"]
        total_bytes = 0
        for k, v in elements.items():
            if v["type"] == "reg":
                if k in children_list:
                    total_bytes += v["bytes"]
        value["total_bytes"] = total_bytes

        

# Render template
outputText = template.render(elements=elements)  
f = open("reg.ralf", 'w+')
f.write(outputText)
f.close()