# Overview
This python script converts the JSON file ,which is compatible with the one in Regvue (https://github.com/nasa-jpl/regvue/tree/main), to RALF (Synopsys). Thus, both documentation and RAL files can be generated with a single JSON file. 

Note: This repo contains a sample JSON file which is named "reg.json"
Note: This script uses a Jinja2 template file which is named "reg.ralf.j2", if needed, it can be updated

# Usage
Just execute this command on the terminal and see the output file "reg.ralf":
```python
python3 jsonToRALF.py
```
You can then import the ralf file into the RALGEN Synopsys tool with this example code snippet to generate UVM RAL classes:
```
ralgen -t Internal_Registers -I . -uvm reg.ralf
```
